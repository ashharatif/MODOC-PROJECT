package com.modoc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringModocApplicationTests {

	@Test
	void contextLoads() {
	}

}
